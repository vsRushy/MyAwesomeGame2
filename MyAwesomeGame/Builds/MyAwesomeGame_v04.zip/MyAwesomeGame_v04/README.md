MyAwesomeGame
-------------

Testing window initialization and movement.

Gerard Marcos Freixas.